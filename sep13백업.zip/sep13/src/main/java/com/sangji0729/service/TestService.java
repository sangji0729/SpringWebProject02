package com.sangji0729.service;

import java.util.List;
import java.util.Map;

public interface TestService {
	List<Map<String, Object>> boardList();//추상 메소드
}
