package com.sangji0729.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

@Repository("testDAO")
public class TestDAO extends AbstractDAO {
	

	@SuppressWarnings("unchecked")
	public List<Map<String, Object>> selectList() {
		return (List<Map<String, Object>>) selectList("test.boardList");
	}
	
	//나중에는 AbstractDAO에 미리 제작해줍니다.
	
}
