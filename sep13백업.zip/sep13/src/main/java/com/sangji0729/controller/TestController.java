package com.sangji0729.controller;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.sangji0729.common.CommandMap;
import com.sangji0729.service.TestServiceImpl;

@Controller
public class TestController {
	//Controller -> Service -> DAO
	
	@Resource(name="testService")
	private TestServiceImpl testService;
	
	@RequestMapping(value = "/main.do")
	public ModelAndView main() {
		//반환타입에 들어갈 수 있는 것 3가지
		//void 			= 반환 타입 없음 = 내부처리만 시키고 끝 = update, insert...
		//String 		= DB에 값 없이 페이지만 호출할 때 = update, insert...
		//ModelAndView	= DB에 질의해서 반환타입을 view로 보낼 때 = list
		//Model			
		ModelAndView mv = new ModelAndView("main");//main.jsp
		//DB에 질의하고 = SELECT
		List<Map<String, Object>> list = testService.boardList();
		mv.addObject("list", list);//key value
		System.out.println(list);
		
		return mv;
	}
	
	@GetMapping("/login.do")
	public String login() {
		return "login";
	}
	
	@PostMapping("/login.do")
	public String login(CommandMap commandMap) {
		//String id = request.getParameter("id");
		//String pw = request.getParameter("pw");
		//System.out.println(id);
		//System.out.println(pw);
		System.out.println(commandMap.getMap());//변환해서 사용
		
		return "redirect:/main.do";
	}
	
	
}
